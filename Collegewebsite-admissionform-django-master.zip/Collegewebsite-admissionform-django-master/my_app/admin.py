from django.contrib import admin
from my_app.models import student 

# Register your models here.
admin.site.register(student)