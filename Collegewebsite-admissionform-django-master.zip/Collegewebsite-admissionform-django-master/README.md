# Collegewebsite-admissionform-django
django project
